import CROOT.FinalNative.Core
import CROOT.FinalNative.GeneratedDependencies.NS.p14_navier_stokes_hard_blocker_core_dependency
import CROOT.FinalNative.GeneratedDependencies.NS.p14_navier_stokes_micro_chain_core_dependency

namespace CROOT
namespace FinalNative

def NavierStokes_OfficialClayNativeStatement : Prop :=
  (officialStatementPayload ProblemId.navierStokes).officialStatement

theorem navier_stokes_current_native_proposition_closed :
    CurrentNativePropositionClosed ProblemId.navierStokes := by
  exact current_native_proposition_closed ProblemId.navierStokes

theorem navier_stokes_official_clay_final_native_theorem :
    NavierStokes_OfficialClayNativeStatement := by
  exact official_statement_closed ProblemId.navierStokes

def navier_stokes_native_receipt : NativeReceipt :=
  nativeReceipt ProblemId.navierStokes

theorem navier_stokes_native_receipt_ready :
    nativeReceiptReady navier_stokes_native_receipt = true := by
  rfl

end FinalNative
end CROOT
