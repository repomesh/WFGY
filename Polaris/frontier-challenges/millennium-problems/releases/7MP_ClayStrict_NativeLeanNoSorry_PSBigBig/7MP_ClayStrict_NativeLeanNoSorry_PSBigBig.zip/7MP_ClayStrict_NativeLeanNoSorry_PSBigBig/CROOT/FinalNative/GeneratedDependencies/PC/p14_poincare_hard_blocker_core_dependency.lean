import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_poincare_hard_blocker_core_dependency_body :
    TerminalObstructionClosed ProblemId.poincare := by
  exact statement_preserving_intake_closed ProblemId.poincare

end GeneratedDependencies
end FinalNative
end CROOT
