import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_yang_mills_micro_chain_core_dependency_body :
    StatementPreservingLoweringClosed ProblemId.yangMills := by
  exact statement_preserving_return_closed ProblemId.yangMills

end GeneratedDependencies
end FinalNative
end CROOT
