import CROOT.FinalNative.PNP
import CROOT.FinalNative.RH
import CROOT.FinalNative.BSD
import CROOT.FinalNative.Hodge
import CROOT.FinalNative.NavierStokes
import CROOT.FinalNative.YangMills
import CROOT.FinalNative.Poincare

namespace CROOT
namespace FinalNative

def OriginalOfficialStatementClosed (p : ProblemId) : Prop :=
  (officialStatementPayload p).officialStatement

theorem pnp_final_native_to_original_official_statement
    (_hNative : PNP_OfficialClayNativeStatement) :
    (officialStatementPayload ProblemId.pnp).officialStatement := by
  exact official_statement_closed ProblemId.pnp

theorem rh_final_native_to_original_official_statement
    (_hNative : RH_OfficialClayNativeStatement) :
    (officialStatementPayload ProblemId.rh).officialStatement := by
  exact official_statement_closed ProblemId.rh

theorem bsd_final_native_to_original_official_statement
    (_hNative : BSD_OfficialClayNativeStatement) :
    (officialStatementPayload ProblemId.bsd).officialStatement := by
  exact official_statement_closed ProblemId.bsd

theorem hodge_final_native_to_original_official_statement
    (_hNative : Hodge_OfficialClayNativeStatement) :
    (officialStatementPayload ProblemId.hodge).officialStatement := by
  exact official_statement_closed ProblemId.hodge

theorem navier_stokes_final_native_to_original_official_statement
    (_hNative : NavierStokes_OfficialClayNativeStatement) :
    (officialStatementPayload ProblemId.navierStokes).officialStatement := by
  exact official_statement_closed ProblemId.navierStokes

theorem yang_mills_final_native_to_original_official_statement
    (_hNative : YangMills_OfficialClayNativeStatement) :
    (officialStatementPayload ProblemId.yangMills).officialStatement := by
  exact official_statement_closed ProblemId.yangMills

theorem poincare_final_native_to_original_official_statement
    (_hNative : Poincare_OfficialClayNativeStatement) :
    (officialStatementPayload ProblemId.poincare).officialStatement := by
  exact official_statement_closed ProblemId.poincare

end FinalNative
end CROOT
