import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_pnp_micro_chain_core_dependency_body :
    StatementPreservingLoweringClosed ProblemId.pnp := by
  exact statement_preserving_return_closed ProblemId.pnp

end GeneratedDependencies
end FinalNative
end CROOT
