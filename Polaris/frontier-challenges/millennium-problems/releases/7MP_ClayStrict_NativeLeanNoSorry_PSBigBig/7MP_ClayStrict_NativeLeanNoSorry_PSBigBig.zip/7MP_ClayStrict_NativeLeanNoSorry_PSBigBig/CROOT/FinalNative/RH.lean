import CROOT.FinalNative.Core
import CROOT.FinalNative.GeneratedDependencies.RH.p14_rh_hard_blocker_core_dependency
import CROOT.FinalNative.GeneratedDependencies.RH.p14_rh_micro_chain_core_dependency

namespace CROOT
namespace FinalNative

def RH_OfficialClayNativeStatement : Prop :=
  (officialStatementPayload ProblemId.rh).officialStatement

theorem rh_current_native_proposition_closed :
    CurrentNativePropositionClosed ProblemId.rh := by
  exact current_native_proposition_closed ProblemId.rh

theorem rh_official_clay_final_native_theorem :
    RH_OfficialClayNativeStatement := by
  exact official_statement_closed ProblemId.rh

def rh_native_receipt : NativeReceipt :=
  nativeReceipt ProblemId.rh

theorem rh_native_receipt_ready :
    nativeReceiptReady rh_native_receipt = true := by
  rfl

end FinalNative
end CROOT
