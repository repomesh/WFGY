import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_hodge_micro_chain_core_dependency_body :
    StatementPreservingLoweringClosed ProblemId.hodge := by
  exact statement_preserving_return_closed ProblemId.hodge

end GeneratedDependencies
end FinalNative
end CROOT
