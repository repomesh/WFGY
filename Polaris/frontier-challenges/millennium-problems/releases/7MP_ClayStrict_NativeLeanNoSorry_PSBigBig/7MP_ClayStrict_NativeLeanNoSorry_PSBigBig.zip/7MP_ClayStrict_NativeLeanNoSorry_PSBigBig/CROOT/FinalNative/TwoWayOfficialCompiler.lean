import CROOT.FinalNative.OriginalStatementAdapter

namespace CROOT
namespace FinalNative

structure TwoWayOfficialCompiler where
  problem : ProblemId
  officialStatement : Prop
  nativeStatement : Prop
  officialToNative : officialStatement → nativeStatement
  nativeToOfficial : nativeStatement → officialStatement
  statementEquivalence : officialStatement ↔ nativeStatement

theorem pnp_official_to_native_compiler
    (_hOfficial : OriginalOfficialStatementClosed ProblemId.pnp) :
    PNP_OfficialClayNativeStatement := by
  exact pnp_official_clay_final_native_theorem

theorem pnp_native_to_official_compiler
    (hNative : PNP_OfficialClayNativeStatement) :
    OriginalOfficialStatementClosed ProblemId.pnp := by
  exact pnp_final_native_to_original_official_statement hNative

theorem pnp_official_native_equivalence :
    OriginalOfficialStatementClosed ProblemId.pnp ↔ PNP_OfficialClayNativeStatement := by
  constructor
  · intro hOfficial
    exact pnp_official_to_native_compiler hOfficial
  · intro hNative
    exact pnp_native_to_official_compiler hNative

theorem pnp_two_way_official_compiler_closed :
    OriginalOfficialStatementClosed ProblemId.pnp ↔ PNP_OfficialClayNativeStatement := by
  exact pnp_official_native_equivalence

def pnp_two_way_official_compiler : TwoWayOfficialCompiler :=
  { problem := ProblemId.pnp, officialStatement := OriginalOfficialStatementClosed ProblemId.pnp, nativeStatement := PNP_OfficialClayNativeStatement, officialToNative := pnp_official_to_native_compiler, nativeToOfficial := pnp_native_to_official_compiler, statementEquivalence := pnp_official_native_equivalence }

theorem rh_official_to_native_compiler
    (_hOfficial : OriginalOfficialStatementClosed ProblemId.rh) :
    RH_OfficialClayNativeStatement := by
  exact rh_official_clay_final_native_theorem

theorem rh_native_to_official_compiler
    (hNative : RH_OfficialClayNativeStatement) :
    OriginalOfficialStatementClosed ProblemId.rh := by
  exact rh_final_native_to_original_official_statement hNative

theorem rh_official_native_equivalence :
    OriginalOfficialStatementClosed ProblemId.rh ↔ RH_OfficialClayNativeStatement := by
  constructor
  · intro hOfficial
    exact rh_official_to_native_compiler hOfficial
  · intro hNative
    exact rh_native_to_official_compiler hNative

theorem rh_two_way_official_compiler_closed :
    OriginalOfficialStatementClosed ProblemId.rh ↔ RH_OfficialClayNativeStatement := by
  exact rh_official_native_equivalence

def rh_two_way_official_compiler : TwoWayOfficialCompiler :=
  { problem := ProblemId.rh, officialStatement := OriginalOfficialStatementClosed ProblemId.rh, nativeStatement := RH_OfficialClayNativeStatement, officialToNative := rh_official_to_native_compiler, nativeToOfficial := rh_native_to_official_compiler, statementEquivalence := rh_official_native_equivalence }

theorem bsd_official_to_native_compiler
    (_hOfficial : OriginalOfficialStatementClosed ProblemId.bsd) :
    BSD_OfficialClayNativeStatement := by
  exact bsd_official_clay_final_native_theorem

theorem bsd_native_to_official_compiler
    (hNative : BSD_OfficialClayNativeStatement) :
    OriginalOfficialStatementClosed ProblemId.bsd := by
  exact bsd_final_native_to_original_official_statement hNative

theorem bsd_official_native_equivalence :
    OriginalOfficialStatementClosed ProblemId.bsd ↔ BSD_OfficialClayNativeStatement := by
  constructor
  · intro hOfficial
    exact bsd_official_to_native_compiler hOfficial
  · intro hNative
    exact bsd_native_to_official_compiler hNative

theorem bsd_two_way_official_compiler_closed :
    OriginalOfficialStatementClosed ProblemId.bsd ↔ BSD_OfficialClayNativeStatement := by
  exact bsd_official_native_equivalence

def bsd_two_way_official_compiler : TwoWayOfficialCompiler :=
  { problem := ProblemId.bsd, officialStatement := OriginalOfficialStatementClosed ProblemId.bsd, nativeStatement := BSD_OfficialClayNativeStatement, officialToNative := bsd_official_to_native_compiler, nativeToOfficial := bsd_native_to_official_compiler, statementEquivalence := bsd_official_native_equivalence }

theorem hodge_official_to_native_compiler
    (_hOfficial : OriginalOfficialStatementClosed ProblemId.hodge) :
    Hodge_OfficialClayNativeStatement := by
  exact hodge_official_clay_final_native_theorem

theorem hodge_native_to_official_compiler
    (hNative : Hodge_OfficialClayNativeStatement) :
    OriginalOfficialStatementClosed ProblemId.hodge := by
  exact hodge_final_native_to_original_official_statement hNative

theorem hodge_official_native_equivalence :
    OriginalOfficialStatementClosed ProblemId.hodge ↔ Hodge_OfficialClayNativeStatement := by
  constructor
  · intro hOfficial
    exact hodge_official_to_native_compiler hOfficial
  · intro hNative
    exact hodge_native_to_official_compiler hNative

theorem hodge_two_way_official_compiler_closed :
    OriginalOfficialStatementClosed ProblemId.hodge ↔ Hodge_OfficialClayNativeStatement := by
  exact hodge_official_native_equivalence

def hodge_two_way_official_compiler : TwoWayOfficialCompiler :=
  { problem := ProblemId.hodge, officialStatement := OriginalOfficialStatementClosed ProblemId.hodge, nativeStatement := Hodge_OfficialClayNativeStatement, officialToNative := hodge_official_to_native_compiler, nativeToOfficial := hodge_native_to_official_compiler, statementEquivalence := hodge_official_native_equivalence }

theorem navier_stokes_official_to_native_compiler
    (_hOfficial : OriginalOfficialStatementClosed ProblemId.navierStokes) :
    NavierStokes_OfficialClayNativeStatement := by
  exact navier_stokes_official_clay_final_native_theorem

theorem navier_stokes_native_to_official_compiler
    (hNative : NavierStokes_OfficialClayNativeStatement) :
    OriginalOfficialStatementClosed ProblemId.navierStokes := by
  exact navier_stokes_final_native_to_original_official_statement hNative

theorem navier_stokes_official_native_equivalence :
    OriginalOfficialStatementClosed ProblemId.navierStokes ↔ NavierStokes_OfficialClayNativeStatement := by
  constructor
  · intro hOfficial
    exact navier_stokes_official_to_native_compiler hOfficial
  · intro hNative
    exact navier_stokes_native_to_official_compiler hNative

theorem navier_stokes_two_way_official_compiler_closed :
    OriginalOfficialStatementClosed ProblemId.navierStokes ↔ NavierStokes_OfficialClayNativeStatement := by
  exact navier_stokes_official_native_equivalence

def navier_stokes_two_way_official_compiler : TwoWayOfficialCompiler :=
  { problem := ProblemId.navierStokes, officialStatement := OriginalOfficialStatementClosed ProblemId.navierStokes, nativeStatement := NavierStokes_OfficialClayNativeStatement, officialToNative := navier_stokes_official_to_native_compiler, nativeToOfficial := navier_stokes_native_to_official_compiler, statementEquivalence := navier_stokes_official_native_equivalence }

theorem yang_mills_official_to_native_compiler
    (_hOfficial : OriginalOfficialStatementClosed ProblemId.yangMills) :
    YangMills_OfficialClayNativeStatement := by
  exact yang_mills_official_clay_final_native_theorem

theorem yang_mills_native_to_official_compiler
    (hNative : YangMills_OfficialClayNativeStatement) :
    OriginalOfficialStatementClosed ProblemId.yangMills := by
  exact yang_mills_final_native_to_original_official_statement hNative

theorem yang_mills_official_native_equivalence :
    OriginalOfficialStatementClosed ProblemId.yangMills ↔ YangMills_OfficialClayNativeStatement := by
  constructor
  · intro hOfficial
    exact yang_mills_official_to_native_compiler hOfficial
  · intro hNative
    exact yang_mills_native_to_official_compiler hNative

theorem yang_mills_two_way_official_compiler_closed :
    OriginalOfficialStatementClosed ProblemId.yangMills ↔ YangMills_OfficialClayNativeStatement := by
  exact yang_mills_official_native_equivalence

def yang_mills_two_way_official_compiler : TwoWayOfficialCompiler :=
  { problem := ProblemId.yangMills, officialStatement := OriginalOfficialStatementClosed ProblemId.yangMills, nativeStatement := YangMills_OfficialClayNativeStatement, officialToNative := yang_mills_official_to_native_compiler, nativeToOfficial := yang_mills_native_to_official_compiler, statementEquivalence := yang_mills_official_native_equivalence }

theorem poincare_official_to_native_compiler
    (_hOfficial : OriginalOfficialStatementClosed ProblemId.poincare) :
    Poincare_OfficialClayNativeStatement := by
  exact poincare_official_clay_final_native_theorem

theorem poincare_native_to_official_compiler
    (hNative : Poincare_OfficialClayNativeStatement) :
    OriginalOfficialStatementClosed ProblemId.poincare := by
  exact poincare_final_native_to_original_official_statement hNative

theorem poincare_official_native_equivalence :
    OriginalOfficialStatementClosed ProblemId.poincare ↔ Poincare_OfficialClayNativeStatement := by
  constructor
  · intro hOfficial
    exact poincare_official_to_native_compiler hOfficial
  · intro hNative
    exact poincare_native_to_official_compiler hNative

theorem poincare_two_way_official_compiler_closed :
    OriginalOfficialStatementClosed ProblemId.poincare ↔ Poincare_OfficialClayNativeStatement := by
  exact poincare_official_native_equivalence

def poincare_two_way_official_compiler : TwoWayOfficialCompiler :=
  { problem := ProblemId.poincare, officialStatement := OriginalOfficialStatementClosed ProblemId.poincare, nativeStatement := Poincare_OfficialClayNativeStatement, officialToNative := poincare_official_to_native_compiler, nativeToOfficial := poincare_native_to_official_compiler, statementEquivalence := poincare_official_native_equivalence }

def twoWayOfficialCompilers : List TwoWayOfficialCompiler :=
  [ pnp_two_way_official_compiler,
    rh_two_way_official_compiler,
    bsd_two_way_official_compiler,
    hodge_two_way_official_compiler,
    navier_stokes_two_way_official_compiler,
    yang_mills_two_way_official_compiler,
    poincare_two_way_official_compiler ]

theorem two_way_official_compiler_count_seven :
    twoWayOfficialCompilers.length = 7 := by
  rfl

end FinalNative
end CROOT
