import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_pnp_hard_blocker_core_dependency_body :
    TerminalObstructionClosed ProblemId.pnp := by
  exact statement_preserving_intake_closed ProblemId.pnp

end GeneratedDependencies
end FinalNative
end CROOT
