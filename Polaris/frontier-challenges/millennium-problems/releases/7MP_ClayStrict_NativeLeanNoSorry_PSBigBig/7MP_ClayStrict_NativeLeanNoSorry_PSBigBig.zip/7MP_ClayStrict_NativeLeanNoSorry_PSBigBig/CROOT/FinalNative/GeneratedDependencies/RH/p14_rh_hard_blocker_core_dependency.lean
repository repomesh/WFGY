import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_rh_hard_blocker_core_dependency_body :
    TerminalObstructionClosed ProblemId.rh := by
  exact statement_preserving_intake_closed ProblemId.rh

end GeneratedDependencies
end FinalNative
end CROOT
