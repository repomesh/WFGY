import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_rh_micro_chain_core_dependency_body :
    StatementPreservingLoweringClosed ProblemId.rh := by
  exact statement_preserving_return_closed ProblemId.rh

end GeneratedDependencies
end FinalNative
end CROOT
