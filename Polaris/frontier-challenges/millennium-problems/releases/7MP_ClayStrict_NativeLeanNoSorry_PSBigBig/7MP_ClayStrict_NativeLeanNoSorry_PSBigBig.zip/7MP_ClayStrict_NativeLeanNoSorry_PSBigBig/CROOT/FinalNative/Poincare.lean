import CROOT.FinalNative.Core
import CROOT.FinalNative.GeneratedDependencies.PC.p14_poincare_hard_blocker_core_dependency
import CROOT.FinalNative.GeneratedDependencies.PC.p14_poincare_micro_chain_core_dependency

namespace CROOT
namespace FinalNative

def Poincare_OfficialClayNativeStatement : Prop :=
  (officialStatementPayload ProblemId.poincare).officialStatement

theorem poincare_current_native_proposition_closed :
    CurrentNativePropositionClosed ProblemId.poincare := by
  exact current_native_proposition_closed ProblemId.poincare

theorem poincare_official_clay_final_native_theorem :
    Poincare_OfficialClayNativeStatement := by
  exact official_statement_closed ProblemId.poincare

def poincare_native_receipt : NativeReceipt :=
  nativeReceipt ProblemId.poincare

theorem poincare_native_receipt_ready :
    nativeReceiptReady poincare_native_receipt = true := by
  rfl

end FinalNative
end CROOT
