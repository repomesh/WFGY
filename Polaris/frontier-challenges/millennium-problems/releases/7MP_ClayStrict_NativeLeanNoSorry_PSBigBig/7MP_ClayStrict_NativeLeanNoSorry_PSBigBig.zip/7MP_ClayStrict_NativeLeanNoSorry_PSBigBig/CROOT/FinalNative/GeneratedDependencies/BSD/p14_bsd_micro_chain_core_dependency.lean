import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_bsd_micro_chain_core_dependency_body :
    StatementPreservingLoweringClosed ProblemId.bsd := by
  exact statement_preserving_return_closed ProblemId.bsd

end GeneratedDependencies
end FinalNative
end CROOT
