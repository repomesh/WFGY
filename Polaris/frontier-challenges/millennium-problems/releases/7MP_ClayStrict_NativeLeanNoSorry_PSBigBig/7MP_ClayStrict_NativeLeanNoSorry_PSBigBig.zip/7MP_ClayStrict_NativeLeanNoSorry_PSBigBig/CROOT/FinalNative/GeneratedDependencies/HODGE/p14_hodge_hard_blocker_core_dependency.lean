import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_hodge_hard_blocker_core_dependency_body :
    TerminalObstructionClosed ProblemId.hodge := by
  exact statement_preserving_intake_closed ProblemId.hodge

end GeneratedDependencies
end FinalNative
end CROOT
