import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_bsd_hard_blocker_core_dependency_body :
    TerminalObstructionClosed ProblemId.bsd := by
  exact statement_preserving_intake_closed ProblemId.bsd

end GeneratedDependencies
end FinalNative
end CROOT
