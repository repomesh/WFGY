import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_navier_stokes_micro_chain_core_dependency_body :
    StatementPreservingLoweringClosed ProblemId.navierStokes := by
  exact statement_preserving_return_closed ProblemId.navierStokes

end GeneratedDependencies
end FinalNative
end CROOT
