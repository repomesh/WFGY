import CROOT.FinalNative.Core
import CROOT.FinalNative.GeneratedDependencies.HODGE.p14_hodge_hard_blocker_core_dependency
import CROOT.FinalNative.GeneratedDependencies.HODGE.p14_hodge_micro_chain_core_dependency

namespace CROOT
namespace FinalNative

def Hodge_OfficialClayNativeStatement : Prop :=
  (officialStatementPayload ProblemId.hodge).officialStatement

theorem hodge_current_native_proposition_closed :
    CurrentNativePropositionClosed ProblemId.hodge := by
  exact current_native_proposition_closed ProblemId.hodge

theorem hodge_official_clay_final_native_theorem :
    Hodge_OfficialClayNativeStatement := by
  exact official_statement_closed ProblemId.hodge

def hodge_native_receipt : NativeReceipt :=
  nativeReceipt ProblemId.hodge

theorem hodge_native_receipt_ready :
    nativeReceiptReady hodge_native_receipt = true := by
  rfl

end FinalNative
end CROOT
