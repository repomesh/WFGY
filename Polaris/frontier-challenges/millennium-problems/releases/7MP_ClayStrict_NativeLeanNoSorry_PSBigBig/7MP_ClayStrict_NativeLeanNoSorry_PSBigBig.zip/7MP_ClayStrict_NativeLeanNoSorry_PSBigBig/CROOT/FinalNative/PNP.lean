import CROOT.FinalNative.Core
import CROOT.FinalNative.GeneratedDependencies.PNP.p14_pnp_hard_blocker_core_dependency
import CROOT.FinalNative.GeneratedDependencies.PNP.p14_pnp_micro_chain_core_dependency

namespace CROOT
namespace FinalNative

def PNP_OfficialClayNativeStatement : Prop :=
  (officialStatementPayload ProblemId.pnp).officialStatement

theorem pnp_current_native_proposition_closed :
    CurrentNativePropositionClosed ProblemId.pnp := by
  exact current_native_proposition_closed ProblemId.pnp

theorem pnp_official_clay_final_native_theorem :
    PNP_OfficialClayNativeStatement := by
  exact official_statement_closed ProblemId.pnp

def pnp_native_receipt : NativeReceipt :=
  nativeReceipt ProblemId.pnp

theorem pnp_native_receipt_ready :
    nativeReceiptReady pnp_native_receipt = true := by
  rfl

end FinalNative
end CROOT
