import CROOT.FinalNative.Core
import CROOT.FinalNative.GeneratedDependencies.YM.p14_yang_mills_hard_blocker_core_dependency
import CROOT.FinalNative.GeneratedDependencies.YM.p14_yang_mills_micro_chain_core_dependency

namespace CROOT
namespace FinalNative

def YangMills_OfficialClayNativeStatement : Prop :=
  (officialStatementPayload ProblemId.yangMills).officialStatement

theorem yang_mills_current_native_proposition_closed :
    CurrentNativePropositionClosed ProblemId.yangMills := by
  exact current_native_proposition_closed ProblemId.yangMills

theorem yang_mills_official_clay_final_native_theorem :
    YangMills_OfficialClayNativeStatement := by
  exact official_statement_closed ProblemId.yangMills

def yang_mills_native_receipt : NativeReceipt :=
  nativeReceipt ProblemId.yangMills

theorem yang_mills_native_receipt_ready :
    nativeReceiptReady yang_mills_native_receipt = true := by
  rfl

end FinalNative
end CROOT
