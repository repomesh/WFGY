import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_yang_mills_hard_blocker_core_dependency_body :
    TerminalObstructionClosed ProblemId.yangMills := by
  exact statement_preserving_intake_closed ProblemId.yangMills

end GeneratedDependencies
end FinalNative
end CROOT
