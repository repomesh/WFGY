import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_poincare_micro_chain_core_dependency_body :
    StatementPreservingLoweringClosed ProblemId.poincare := by
  exact statement_preserving_return_closed ProblemId.poincare

end GeneratedDependencies
end FinalNative
end CROOT
