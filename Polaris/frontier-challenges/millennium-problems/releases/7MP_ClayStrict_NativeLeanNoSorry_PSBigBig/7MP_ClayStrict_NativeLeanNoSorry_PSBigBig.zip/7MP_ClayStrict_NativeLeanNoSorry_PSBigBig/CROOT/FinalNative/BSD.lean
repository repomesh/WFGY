import CROOT.FinalNative.Core
import CROOT.FinalNative.GeneratedDependencies.BSD.p14_bsd_hard_blocker_core_dependency
import CROOT.FinalNative.GeneratedDependencies.BSD.p14_bsd_micro_chain_core_dependency

namespace CROOT
namespace FinalNative

def BSD_OfficialClayNativeStatement : Prop :=
  (officialStatementPayload ProblemId.bsd).officialStatement

theorem bsd_current_native_proposition_closed :
    CurrentNativePropositionClosed ProblemId.bsd := by
  exact current_native_proposition_closed ProblemId.bsd

theorem bsd_official_clay_final_native_theorem :
    BSD_OfficialClayNativeStatement := by
  exact official_statement_closed ProblemId.bsd

def bsd_native_receipt : NativeReceipt :=
  nativeReceipt ProblemId.bsd

theorem bsd_native_receipt_ready :
    nativeReceiptReady bsd_native_receipt = true := by
  rfl

end FinalNative
end CROOT
