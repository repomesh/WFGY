import CROOT.FinalNative.Core

namespace CROOT
namespace FinalNative
namespace GeneratedDependencies

theorem p18_navier_stokes_hard_blocker_core_dependency_body :
    TerminalObstructionClosed ProblemId.navierStokes := by
  exact statement_preserving_intake_closed ProblemId.navierStokes

end GeneratedDependencies
end FinalNative
end CROOT
