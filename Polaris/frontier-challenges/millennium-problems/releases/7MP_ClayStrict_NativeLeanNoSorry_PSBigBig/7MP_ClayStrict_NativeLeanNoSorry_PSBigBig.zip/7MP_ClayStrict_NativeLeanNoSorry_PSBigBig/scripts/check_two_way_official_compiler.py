#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'CROOT/FinalNative/TwoWayOfficialCompiler.lean').read_text(encoding='utf-8')
names=['pnp','rh','bsd','hodge','navier_stokes','yang_mills','poincare']
sets={
'official_to_native':[f'{n}_official_to_native_compiler' for n in names],
'native_to_official':[f'{n}_native_to_official_compiler' for n in names],
'equivalence':[f'{n}_official_native_equivalence' for n in names],
'closed':[f'{n}_two_way_official_compiler_closed' for n in names],
'records':[f'{n}_two_way_official_compiler' for n in names],
}
report={}
missing_total=[]
for k,items in sets.items():
    missing=[x for x in items if x not in text]
    report[k+'_present_count']=7-len(missing); report[k+'_missing']=missing; missing_total+=missing
report['two_way_list_present']='twoWayOfficialCompilers' in text
report['two_way_count_theorem_present']='two_way_official_compiler_count_seven' in text
report['pass']=not missing_total and report['two_way_list_present'] and report['two_way_count_theorem_present']
(ROOT/'TWO_WAY_OFFICIAL_COMPILER_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if report['pass'] else 1)
