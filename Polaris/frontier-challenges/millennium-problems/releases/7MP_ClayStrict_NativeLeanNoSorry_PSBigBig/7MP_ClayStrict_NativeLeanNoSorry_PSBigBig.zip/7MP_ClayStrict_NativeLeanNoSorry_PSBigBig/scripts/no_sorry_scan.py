#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parents[1]
patterns = [re.compile(r"\bsorry\b"), re.compile(r"\badmit\b"), re.compile(r"\baxiom\b")]
hits=[]
for p in (ROOT/'CROOT').rglob('*.lean'):
    text=p.read_text(encoding='utf-8',errors='ignore')
    for i,line in enumerate(text.splitlines(),1):
        for pat in patterns:
            if pat.search(line): hits.append({'file':str(p.relative_to(ROOT)),'line':i,'content':line.strip()})
report={'checked_lean_files':len(list((ROOT/'CROOT').rglob('*.lean'))),'hit_count':len(hits),'hits':hits,'pass':not hits}
(ROOT/'NO_SORRY_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if report['pass'] else 1)
