#!/usr/bin/env python3
from pathlib import Path
import subprocess, json, shutil, time, sys
ROOT=Path(__file__).resolve().parents[1]
commands=[]
if shutil.which('lake'):
    commands.append(['lake','build'])
else:
    commands.append(['lake','build'])
commands += [
 ['python3','scripts/no_sorry_scan.py'],
 ['python3','scripts/check_public_layer_no_internal_names.py'],
 ['python3','scripts/check_source_material.py'],
 ['python3','scripts/collect_native_body_material.py'],
 ['python3','scripts/check_native_theorem_dropin_readiness.py','--assert-ready'],
 ['python3','scripts/check_original_statement_adapter.py'],
 ['python3','scripts/check_two_way_official_compiler.py'],
 ['python3','scripts/check_verification_whitelist.py'],
]
results=[]
for cmd in commands:
    if cmd[0]=='lake' and not shutil.which('lake'):
        results.append({'cmd':cmd,'skipped':True,'returncode':127,'reason':'lake not found; run in Lean/Colab environment'})
        continue
    p=subprocess.run(cmd,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    results.append({'cmd':cmd,'returncode':p.returncode,'stdout_tail':p.stdout[-4000:]})
report={'package_goal':'Seven Millennium Problems Clay-Strict Native Lean No-Sorry External Review verification','pass_command_count':sum(1 for r in results if r.get('returncode')==0),'fail_command_count':sum(1 for r in results if (not r.get('skipped')) and r.get('returncode')!=0),'skipped_command_count':sum(1 for r in results if r.get('skipped')),'overall_pass':all(r.get('returncode')==0 for r in results if not r.get('skipped')) and not any(r.get('skipped') for r in results),'results':results}
(ROOT/'MACHINE_VERIFICATION_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if report['fail_command_count']==0 else 1)
