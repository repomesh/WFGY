#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'CROOT/FinalNative/OriginalStatementAdapter.lean').read_text(encoding='utf-8')
names=['pnp','rh','bsd','hodge','navier_stokes','yang_mills','poincare']
missing=[f'{n}_final_native_to_original_official_statement' for n in names if f'{n}_final_native_to_original_official_statement' not in text]
report={'adapter_bridge_expected_count':7,'adapter_bridge_present_count':7-len(missing),'missing':missing,'pass':not missing}
(ROOT/'ORIGINAL_STATEMENT_ADAPTER_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if report['pass'] else 1)
