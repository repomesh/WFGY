#!/usr/bin/env python3
from pathlib import Path
import argparse,json,subprocess,sys,re
ROOT=Path(__file__).resolve().parents[1]
mat=ROOT/'NATIVE_BODY_MATERIAL_REPORT.json'
if not mat.exists(): subprocess.run([sys.executable,'scripts/collect_native_body_material.py'],cwd=ROOT,check=True)
data=json.loads(mat.read_text())
ready=[]
for p in data['problems']:
    missing=[]
    if not p['native_theorem_decl_exists']: missing.append('native_declaration_present')
    if not p['native_theorem_ready']: missing.append('proof_body_present')
    if not p['proof_body_slot_ready']: missing.append('dependency_receipt_ready')
    if not p['final_object_slot_ready']: missing.append('verifier_receipt_ready')
    ready.append({'problem_id':p['problem_id'],'final_theorem_object':p['final_theorem_object'],'expected_file':p['expected_file'],'missing_receipts':missing,'ready_for_native_claim':not missing})
report={'problem_count':7,'ready_problem_count':sum(x['ready_for_native_claim'] for x in ready),'remaining_receipt_lane_count':sum(len(x['missing_receipts']) for x in ready),'can_unlock_native_claim':all(x['ready_for_native_claim'] for x in ready),'problems':ready}
(ROOT/'FINAL_NATIVE_THEOREM_BODY_DROPIN_READINESS_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
args=argparse.ArgumentParser(); args.add_argument('--assert-ready',action='store_true'); ns=args.parse_args()
if ns.assert_ready and not report['can_unlock_native_claim']: sys.exit(2)
