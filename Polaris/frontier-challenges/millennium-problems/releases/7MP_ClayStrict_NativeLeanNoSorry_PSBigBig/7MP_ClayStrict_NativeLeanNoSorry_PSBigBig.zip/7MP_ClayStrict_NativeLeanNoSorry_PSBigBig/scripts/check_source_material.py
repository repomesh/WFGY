#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "source_material" / "SEVEN_MILLENNIUM_PROBLEMS"
EXPECTED = {pid: f"{pid}_EXTERNAL_THEOREM_REVIEW_LEDGER.json" for pid in ["PNP","RH","BSD","HODGE","NS","YM","PC"]}
items=[]; ok=True
for pid,fn in EXPECTED.items():
    path=SOURCE_ROOT/pid/fn
    item={'problem_id':pid,'expected_path':str(path.relative_to(ROOT)),'exists':path.exists(),'formalization_cells_total':0,'formalization_cells_closed':0,'open_obligations':None,'review_layer_closed':False}
    if path.exists():
        data=json.loads(path.read_text())
        item['formalization_cells_total']=data.get('formalization_cells_total')
        item['formalization_cells_closed']=data.get('formalization_cells_closed')
        item['open_obligations']=data.get('open_obligations')
        item['review_layer_closed']=data.get('review_layer_status')=='CLOSED_FOR_NATIVE_LEAN_REPLAY'
    ok = ok and item['exists'] and item['formalization_cells_total']==9 and item['formalization_cells_closed']==9 and item['open_obligations']==0 and item['review_layer_closed']
    items.append(item)
report={'source_root':str(SOURCE_ROOT.relative_to(ROOT)),'source_root_exists':SOURCE_ROOT.exists(),'problem_count':len(items),'ledger_found_count':sum(x['exists'] for x in items),'formalization_cell_total':sum(x['formalization_cells_total'] or 0 for x in items),'review_layer_closed_count':sum(x['review_layer_closed'] for x in items),'strict_source_material_packaged':ok,'problems':items}
(ROOT/'SOURCE_MATERIAL_PACKAGE_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if ok else 1)
