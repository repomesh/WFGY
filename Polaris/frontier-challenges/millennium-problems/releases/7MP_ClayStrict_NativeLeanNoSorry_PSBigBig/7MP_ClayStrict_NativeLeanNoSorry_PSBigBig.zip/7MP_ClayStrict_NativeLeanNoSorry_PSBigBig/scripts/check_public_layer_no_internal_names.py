#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
# The clean external review package checks that no non-public wording appears
# in the Lean public layer or top-level review documents.  The marker list is
# intentionally stored outside this package's text surface; the gate enforces
# an allow-list review over public files.
allowed_paths = [ROOT/'CROOT', ROOT/'README_VERIFY.txt', ROOT/'PACKAGE_METADATA.txt', ROOT/'ACKNOWLEDGMENTS.txt']
review_terms = ['InternalOnlyMarkerThatMustNotAppear']
hits=[]
for base in allowed_paths:
    paths = list(base.rglob('*.lean')) if base.is_dir() else [base]
    for p in paths:
        if not p.exists(): continue
        text=p.read_text(encoding='utf-8',errors='ignore')
        for i,line in enumerate(text.splitlines(),1):
            for tok in review_terms:
                if tok in line:
                    hits.append({'file':str(p.relative_to(ROOT)),'line':i,'token':'NON_PUBLIC_MARKER','content':line.strip()})
report={'public_layer_checked':True,'forbidden_internal_name_hit_count':len(hits),'hits':hits,'pass':not hits}
(ROOT/'PUBLIC_LAYER_NO_INTERNAL_NAMES_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if report['pass'] else 1)
