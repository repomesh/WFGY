#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, shutil, time
ROOT=Path(__file__).resolve().parents[1]
report={'lake_available':shutil.which('lake') is not None,'lean_available':shutil.which('lean') is not None,'note':'Run lake build in the verification environment for machine replay.'}
(ROOT/'BUILD_REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
