import Lake
open Lake DSL

package «CROOT» where

@[default_target]
lean_lib CROOT where
  roots := #[`CROOT]
